// utils/cloud.js - 云开发工具封装
const app = getApp();

// 调用云函数
async function callFunction(name, data = {}) {
  try {
    const res = await wx.cloud.callFunction({
      name,
      data,
    });
    if (res.result && res.result.code !== undefined) {
      if (res.result.code === 0) {
        return res.result.data;
      } else {
        throw new Error(res.result.msg || '请求失败');
      }
    }
    return res.result;
  } catch (err) {
    console.error(`云函数 ${name} 调用失败:`, err);
    wx.showToast({ title: err.message || '网络错误', icon: 'none' });
    throw err;
  }
}

// 上传文件到云存储
async function uploadFile(filePath, cloudPath) {
  const ext = filePath.split('.').pop();
  const fileName = cloudPath || `${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`;
  const result = await wx.cloud.uploadFile({
    cloudPath: `uploads/${fileName}`,
    filePath,
  });
  return result.fileID;
}

// 获取文件临时链接
async function getTempFileURL(fileID) {
  const res = await wx.cloud.getTempFileURL({ fileList: [fileID] });
  return res.fileList[0].tempFileURL;
}

// 微信一键登录
async function wxLogin() {
  // 获取登录code
  const loginRes = await wx.login();
  if (!loginRes.code) throw new Error('微信登录失败');

  // 调用云函数登录
  const userInfo = await callFunction('user', {
    action: 'wxLogin',
    code: loginRes.code,
  });

  // 保存登录状态
  wx.setStorageSync('token', userInfo.token);
  wx.setStorageSync('userInfo', userInfo);
  app.globalData.userInfo = userInfo;
  app.globalData.isVip = userInfo.vipLevel !== 'free';

  return userInfo;
}

// 手机号登录
async function phoneLogin(code) {
  const userInfo = await callFunction('user', {
    action: 'phoneLogin',
    code,
  });

  wx.setStorageSync('token', userInfo.token);
  wx.setStorageSync('userInfo', userInfo);
  app.globalData.userInfo = userInfo;
  app.globalData.isVip = userInfo.vipLevel !== 'free';

  return userInfo;
}

// 检查登录状态
function checkLogin() {
  const userInfo = wx.getStorageSync('userInfo');
  if (!userInfo) return false;
  app.globalData.userInfo = userInfo;
  app.globalData.isVip = userInfo.vipLevel !== 'free';
  return true;
}

// 退出登录
function logout() {
  wx.removeStorageSync('token');
  wx.removeStorageSync('userInfo');
  app.globalData.userInfo = null;
  app.globalData.isVip = false;
}

module.exports = {
  callFunction,
  uploadFile,
  getTempFileURL,
  wxLogin,
  phoneLogin,
  checkLogin,
  logout,
};
