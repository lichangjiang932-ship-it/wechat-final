// pages/discover/discover.js - 暖感真实风
const { callFunction } = require('../../utils/cloud');

const TABS = ['推荐', '写真', '证件照', '艺术', '动漫'];

// 使用本地图片
const MOCK_WORKS = [
  { id: 1, title: '最美证件照', cover: '/images/covers/cover-portrait.jpg', likes: 1280, h: 320 },
  { id: 2, title: '日系写真', cover: '/images/covers/cover-art.jpg', likes: 960, h: 400 },
  { id: 3, title: '水彩插画', cover: '/images/covers/cover-watercolor.jpg', likes: 856, h: 280 },
  { id: 4, title: '国风古韵', cover: '/images/covers/cover-chinese.jpg', likes: 742, h: 380 },
  { id: 5, title: '赛博朋克', cover: '/images/covers/cover-cyberpunk.jpg', likes: 621, h: 300 },
  { id: 6, title: '油画质感', cover: '/images/covers/inspire-warm.jpg', likes: 580, h: 360 },
  { id: 7, title: '二次元', cover: '/images/covers/cover-anime.jpg', likes: 432, h: 340 },
  { id: 8, title: '粘土风', cover: '/images/covers/cover-clay.jpg', likes: 389, h: 260 },
];

Page({
  data: {
    tabs: TABS, activeTab: '推荐',
    leftCol: [], rightCol: [],
    hasMore: false, page: 1,
    navBarHeight: 44, statusBarHeight: 20,
  },

  onLoad() {
    this.computeNavBar();
    this.loadWorks();
  },
  onShow() {
    if (typeof this.getTabBar === 'function' && this.getTabBar()) this.getTabBar().setData({ selected: 2 });
  },

  computeNavBar() {
    try {
      const menu = wx.getMenuButtonBoundingClientRect();
      const windowInfo = wx.getWindowInfo();
      this.setData({
        navBarHeight: (menu.top - windowInfo.statusBarHeight) * 2 + menu.height + windowInfo.statusBarHeight,
        statusBarHeight: windowInfo.statusBarHeight,
      });
    } catch (e) {}
  },

  loadWorks() {
    const works = MOCK_WORKS.slice(0, this.data.page * 8);
    
    // 检查收藏状态
    const favorites = wx.getStorageSync('myFavorites') || [];
    const favoriteIds = favorites.map(f => f.id);
    
    works.forEach(w => {
      w.isFavorited = favoriteIds.includes(w.id);
    });
    
    const left = works.filter((_, i) => i % 2 === 0);
    const right = works.filter((_, i) => i % 2 !== 0);
    this.setData({ leftCol: left, rightCol: right, hasMore: works.length < MOCK_WORKS.length });
  },

  // 切换收藏状态
  onToggleFavorite(e) {
    const item = e.currentTarget.dataset.item;
    const favorites = wx.getStorageSync('myFavorites') || [];
    const index = favorites.findIndex(f => f.id === item.id);
    
    if (index > -1) {
      // 已收藏，取消收藏
      favorites.splice(index, 1);
      wx.showToast({ title: '已取消收藏', icon: 'none' });
    } else {
      // 未收藏，添加收藏
      favorites.unshift({
        id: item.id,
        url: item.cover,
        title: item.title,
        likes: item.likes,
      });
      wx.showToast({ title: '已收藏', icon: 'success' });
    }
    
    wx.setStorageSync('myFavorites', favorites);
    
    // 更新列表显示
    this.loadWorks();
  },

  switchTab(e) {
    wx.vibrateShort({ type: 'light' });
    this.setData({ activeTab: e.currentTarget.dataset.tab, page: 1 }, () => this.loadWorks());
  },
  loadMore() { this.setData({ page: this.data.page + 1 }, () => this.loadWorks()); },

  // 点击图片 - 跳转到详情页
  onImageTap(e) {
    const item = e.currentTarget.dataset.item;
    wx.navigateTo({
      url: `/pages/preview/preview?url=${encodeURIComponent(item.cover)}&title=${encodeURIComponent(item.title)}&likes=${item.likes}`
    });
  },

  // 预览图片 - 跳转到详情页
  previewImage(e) {
    const src = e.currentTarget.dataset.src;
    wx.navigateTo({
      url: `/pages/preview/preview?url=${encodeURIComponent(src)}`
    });
  },

  // 做同款 - 跳转到创作页
  onMakeSame(e) {
    const item = e.currentTarget.dataset.item;

    // 创作页是 tabBar 页面，不能用 navigateTo，需要用 switchTab
    // 通过 storage 传递参数
    wx.setStorageSync('makeSameParams', {
      cover: item.cover,
      title: item.title,
    });

    wx.switchTab({
      url: '/pages/create/create',
      fail: (err) => {
        console.error('跳转失败:', err);
        wx.showToast({ title: '跳转失败', icon: 'none' });
      }
    });
  },
  onShareAppMessage() { return { title: 'AI写真 - 发现灵感', path: '/pages/discover/discover' }; },
});
