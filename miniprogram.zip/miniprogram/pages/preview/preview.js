// pages/preview/preview.js - 图片详情页
Page({
  data: {
    imageUrl: '',
    title: '',
    likes: 0,
    imageLoaded: false,
    navBarHeight: 44,
    statusBarHeight: 20,
  },

  onLoad(options) {
    this.computeNavBar();
    
    if (options.url) {
      this.setData({ imageUrl: decodeURIComponent(options.url) });
    }
    if (options.title) {
      this.setData({ title: decodeURIComponent(options.title) });
    }
    if (options.likes) {
      this.setData({ likes: options.likes });
    }
  },

  computeNavBar() {
    try {
      const windowInfo = wx.getWindowInfo();
      const menuBtn = wx.getMenuButtonBoundingClientRect();
      this.setData({
        navBarHeight: (menuBtn.top - windowInfo.statusBarHeight) * 2 + menuBtn.height + windowInfo.statusBarHeight,
        statusBarHeight: windowInfo.statusBarHeight,
      });
    } catch (e) {}
  },

  goBack() {
    wx.navigateBack();
  },

  onImageLoad() {
    this.setData({ imageLoaded: true });
  },

  onImageTap() {
    wx.previewImage({
      current: this.data.imageUrl,
      urls: [this.data.imageUrl],
    });
  },

  onMakeSame() {
    if (!this.data.imageUrl) {
      wx.showToast({ title: '图片未加载，请稍后', icon: 'none' });
      return;
    }

    // 创作页是 tabBar 页面，不能用 navigateTo，需要用 switchTab
    // 通过 storage 传递参数
    wx.setStorageSync('makeSameParams', {
      cover: this.data.imageUrl,
      title: this.data.title || '作品',
    });

    wx.switchTab({
      url: '/pages/create/create',
      fail: (err) => {
        console.error('跳转失败:', err);
        wx.showToast({ title: '跳转失败', icon: 'none' });
      }
    });
  },

  onShareAppMessage() {
    return {
      title: this.data.title || '照片工坊作品',
      path: '/pages/preview/preview',
    };
  },
});
