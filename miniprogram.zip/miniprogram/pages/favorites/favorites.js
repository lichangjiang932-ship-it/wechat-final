// pages/favorites/favorites.js - 我的收藏页面
Page({
  data: {
    navBarHeight: 44,
    statusBarHeight: 20,
    favorites: [],
  },

  onLoad() {
    this.computeNavBar();
    this.loadFavorites();
  },

  onShow() {
    this.loadFavorites();
  },

  computeNavBar() {
    try {
      const windowInfo = wx.getWindowInfo();
      const menuBtn = wx.getMenuButtonBoundingClientRect();
      this.setData({
        navBarHeight: (menuBtn.top - windowInfo.statusBarHeight) * 2 + menuBtn.height + windowInfo.statusBarHeight,
        statusBarHeight: windowInfo.statusBarHeight,
      });
    } catch (e) {}
  },

  loadFavorites() {
    const favorites = wx.getStorageSync('myFavorites') || [];
    this.setData({ favorites });
  },

  goBack() {
    wx.navigateBack();
  },

  goDiscover() {
    wx.switchTab({ url: '/pages/discover/discover' });
  },

  onPreview(e) {
    const index = e.currentTarget.dataset.index;
    const urls = this.data.favorites.map(f => f.url);
    wx.previewImage({
      current: urls[index],
      urls: urls,
    });
  },

  onMakeSame(e) {
    const item = e.currentTarget.dataset.item;
    wx.navigateTo({
      url: `/pages/create/create?cover=${encodeURIComponent(item.url)}&title=${encodeURIComponent(item.title || '作品')}`
    });
  },

  onRemove(e) {
    const id = e.currentTarget.dataset.id;
    wx.showModal({
      title: '提示',
      content: '确定取消收藏吗？',
      success: res => {
        if (res.confirm) {
          let favorites = wx.getStorageSync('myFavorites') || [];
          favorites = favorites.filter(f => f.id !== id);
          wx.setStorageSync('myFavorites', favorites);
          this.setData({ favorites });
          wx.showToast({ title: '已取消收藏', icon: 'success' });
        }
      },
    });
  },

  onShareAppMessage() {
    return {
      title: '照片工坊 - 我的收藏',
      path: '/pages/favorites/favorites',
    };
  },
});
