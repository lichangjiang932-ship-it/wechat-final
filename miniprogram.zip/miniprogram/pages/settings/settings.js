// pages/settings/settings.js - 设置页面
Page({
  data: {
    navBarHeight: 44,
    statusBarHeight: 20,
    userInfo: null,
    userId: '',
  },

  onLoad() {
    this.computeNavBar();
    this.loadUserInfo();
  },

  onShow() {
    this.loadUserInfo();
  },

  computeNavBar() {
    try {
      const windowInfo = wx.getWindowInfo();
      const menuBtn = wx.getMenuButtonBoundingClientRect();
      this.setData({
        navBarHeight: (menuBtn.top - windowInfo.statusBarHeight) * 2 + menuBtn.height + windowInfo.statusBarHeight,
        statusBarHeight: windowInfo.statusBarHeight,
      });
    } catch (e) {}
  },

  loadUserInfo() {
    const userInfo = wx.getStorageSync('userInfo');
    this.setData({ userInfo });
    if (userInfo && userInfo.loginTime) {
      // 生成简短用户ID
      this.setData({ userId: String(userInfo.loginTime).slice(-8) });
    }
  },

  goBack() {
    wx.navigateBack();
  },

  // 编辑资料
  onEditProfile() {
    wx.showToast({ title: '功能开发中', icon: 'none' });
  },

  // 更换头像
  onChangeAvatar() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: res => {
        const tempFilePath = res.tempFiles[0].tempFilePath;
        // 更新用户信息
        const userInfo = wx.getStorageSync('userInfo') || {};
        userInfo.avatarUrl = tempFilePath;
        wx.setStorageSync('userInfo', userInfo);
        // 更新全局数据
        const app = getApp();
        if (app.globalData) {
          app.globalData.userInfo = userInfo;
        }
        this.setData({ userInfo });
        wx.showToast({ title: '头像已更新', icon: 'success' });
      },
    });
  },

  // 关于我们
  onAbout() {
    wx.showModal({
      title: '关于我们',
      content: '照片工坊 v1.1.0\n\n一款温暖质感的 AI 照片处理小程序。\n\n支持 AI 写真、证件照、风格迁移等功能。',
      showCancel: false,
    });
  },

  // 隐私政策
  onPrivacy() {
    wx.showModal({
      title: '隐私政策',
      content: '照片工坊隐私政策\n\n我们重视您的隐私保护：\n\n1. 我们仅收集必要的信息用于提供服务\n2. 您的头像和昵称仅用于个人资料展示\n3. 您上传的图片仅用于 AI 处理，不会被保存或分享\n4. 我们不会将您的信息提供给第三方',
      showCancel: false,
    });
  },

  // 用户协议
  onAgreement() {
    wx.showModal({
      title: '用户协议',
      content: '照片工坊用户协议\n\n1. 请遵守当地法律法规使用本服务\n2. 请勿上传违法、有害的内容\n3. 生成的图片可用于个人用途\n4. 如有问题，请联系我们',
      showCancel: false,
    });
  },

  // 退出登录
  onLogout() {
    wx.showModal({
      title: '提示',
      content: '确定要退出登录吗？',
      success: res => {
        if (res.confirm) {
          // 清除登录状态
          wx.removeStorageSync('userInfo');
          wx.removeStorageSync('token');
          wx.removeStorageSync('loginCache');
          
          // 清除全局数据
          const app = getApp();
          if (app.globalData) {
            app.globalData.userInfo = null;
            app.globalData.token = null;
            app.globalData.isVip = false;
          }
          
          wx.showToast({ title: '已退出登录', icon: 'success' });
          wx.navigateBack();
        }
      },
    });
  },
});
