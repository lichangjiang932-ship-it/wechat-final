// pages/history/history.js - 我的作品页面
Page({
  data: {
    navBarHeight: 44,
    statusBarHeight: 20,
    works: [],
  },

  onLoad() {
    this.computeNavBar();
    this.loadWorks();
  },

  onShow() {
    this.loadWorks();
  },

  computeNavBar() {
    try {
      const windowInfo = wx.getWindowInfo();
      const menuBtn = wx.getMenuButtonBoundingClientRect();
      this.setData({
        navBarHeight: (menuBtn.top - windowInfo.statusBarHeight) * 2 + menuBtn.height + windowInfo.statusBarHeight,
        statusBarHeight: windowInfo.statusBarHeight,
      });
    } catch (e) {}
  },

  loadWorks() {
    // 从本地存储加载作品
    const works = wx.getStorageSync('myWorks') || [];
    this.setData({ works });
  },

  goBack() {
    wx.navigateBack();
  },

  goCreate() {
    wx.switchTab({ url: '/pages/create/create' });
  },

  onPreview(e) {
    const index = e.currentTarget.dataset.index;
    const urls = this.data.works.map(w => w.url);
    wx.previewImage({
      current: urls[index],
      urls: urls,
    });
  },

  onSave(e) {
    const item = e.currentTarget.dataset.item;
    wx.saveImageToPhotosAlbum({
      filePath: item.url,
      success: () => wx.showToast({ title: '已保存', icon: 'success' }),
      fail: err => {
        if (err.errMsg.includes('auth deny')) {
          wx.showModal({
            title: '需要权限',
            content: '请在设置中开启相册权限',
            success: res => {
              if (res.confirm) wx.openSetting();
            },
          });
        }
      },
    });
  },

  onShare(e) {
    const item = e.currentTarget.dataset.item;
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline'],
    });
  },

  onShareAppMessage() {
    return {
      title: '照片工坊 - 我的作品',
      path: '/pages/history/history',
    };
  },
});
