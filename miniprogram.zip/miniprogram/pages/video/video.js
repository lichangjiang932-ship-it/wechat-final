// pages/video/video.js
const { callFunction } = require('../../utils/cloud');

Page({
  data: {
    categories: [],
    activeCategory: '',
    videos: [],
    loading: false,
    page: 1,
    pageSize: 10,
    hasMore: true,
  },

  onLoad() {
    this.loadCategories();
    this.loadVideos();
  },

  onShow() {
    // 刷新数据
  },

  // 下拉刷新
  onPullDownRefresh() {
    this.setData({ page: 1, hasMore: true });
    Promise.all([this.loadCategories(), this.loadVideos()]).then(() => {
      wx.stopPullDownRefresh();
    });
  },

  // 上拉加载更多
  onReachBottom() {
    if (this.data.hasMore && !this.data.loading) {
      this.loadMoreVideos();
    }
  },

  // 加载分类
  async loadCategories() {
    try {
      const categories = await callFunction('video', { action: 'categories' });
      this.setData({ categories: categories || [] });
    } catch (e) {
      console.error('加载分类失败', e);
    }
  },

  // 加载视频
  async loadVideos() {
    this.setData({ loading: true });
    try {
      const videos = await callFunction('video', {
        action: 'list',
        categoryId: this.data.activeCategory,
        page: 1,
        pageSize: this.data.pageSize,
      });
      this.setData({
        videos: videos || [],
        page: 1,
        hasMore: (videos || []).length >= this.data.pageSize,
      });
    } catch (e) {
      console.error('加载视频失败', e);
    } finally {
      this.setData({ loading: false });
    }
  },

  // 加载更多
  async loadMoreVideos() {
    this.setData({ loading: true });
    const nextPage = this.data.page + 1;
    try {
      const videos = await callFunction('video', {
        action: 'list',
        categoryId: this.data.activeCategory,
        page: nextPage,
        pageSize: this.data.pageSize,
      });
      const newList = videos || [];
      this.setData({
        videos: [...this.data.videos, ...newList],
        page: nextPage,
        hasMore: newList.length >= this.data.pageSize,
      });
    } catch (e) {
      console.error('加载更多视频失败', e);
    } finally {
      this.setData({ loading: false });
    }
  },

  // 切换分类
  onCategoryTap(e) {
    const id = e.currentTarget.dataset.id;
    this.setData({ activeCategory: id, page: 1, hasMore: true });
    this.loadVideos();
  },

  // 跳转详情
  goDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: `/pages/video-detail/video-detail?id=${id}` });
  },
});
