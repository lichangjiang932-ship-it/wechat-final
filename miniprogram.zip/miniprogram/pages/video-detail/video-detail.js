// pages/video-detail/video-detail.js
const { callFunction, checkLogin } = require('../../utils/cloud');
const app = getApp();

Page({
  data: {
    videoId: '',
    video: {},
    isCollected: false,
    isVip: false,
  },

  onLoad(options) {
    this.setData({
      videoId: options.id,
      isVip: app.globalData.isVip,
    });
    this.loadVideoDetail();
  },

  onShow() {
    this.setData({ isVip: app.globalData.isVip });
  },

  // 加载视频详情
  async loadVideoDetail() {
    try {
      const video = await callFunction('video', {
        action: 'detail',
        id: this.data.videoId,
      });
      if (!video) {
        wx.showToast({ title: '视频不存在', icon: 'none' });
        setTimeout(() => wx.navigateBack(), 1500);
        return;
      }
      // 格式化视频URL（云存储fileID转临时链接）
      if (video.videoFileID) {
        const res = await wx.cloud.getTempFileURL({ fileList: [video.videoFileID] });
        video.videoUrl = res.fileList[0].tempFileURL;
      }
      if (video.coverFileID) {
        const res = await wx.cloud.getTempFileURL({ fileList: [video.coverFileID] });
        video.coverUrl = res.fileList[0].tempFileURL;
      }
      this.setData({ video });

      // 检查收藏状态
      if (checkLogin()) {
        this.checkCollection();
      }
    } catch (e) {
      console.error('加载视频详情失败', e);
    }
  },

  // 检查收藏状态
  async checkCollection() {
    try {
      const res = await callFunction('collection', {
        action: 'check',
        videoId: this.data.videoId,
      });
      this.setData({ isCollected: !!res });
    } catch (e) {}
  },

  // 切换收藏
  async toggleCollect() {
    if (!checkLogin()) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }
    try {
      await callFunction('collection', {
        action: this.data.isCollected ? 'remove' : 'add',
        videoId: this.data.videoId,
      });
      this.setData({ isCollected: !this.data.isCollected });
      wx.showToast({
        title: this.data.isCollected ? '已收藏' : '已取消收藏',
        icon: 'success',
      });
    } catch (e) {
      wx.showToast({ title: '操作失败', icon: 'none' });
    }
  },

  // 视频开始播放 - 记录观看历史
  async onVideoPlay() {
    if (!checkLogin()) return;
    try {
      await callFunction('collection', {
        action: 'addHistory',
        videoId: this.data.videoId,
      });
    } catch (e) {}
  },

  // 跳转会员页
  goMember() {
    wx.switchTab({ url: '/pages/member/member' });
  },

  // 分享
  onShare() {
    return {
      title: this.data.video.title,
      path: `/pages/video-detail/video-detail?id=${this.data.videoId}`,
    };
  },

  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: this.data.video.title,
    };
  },
});
