// pages/member/member.js - 会员页面
Page({
  data: {
    userInfo: null,
    vipLevel: 'free',
    vipLevelText: '普通用户',
    vipExpireTime: '',
    selectedPlan: 'month',
    navBarHeight: 44,
    statusBarHeight: 20,
  },

  onLoad() {
    this.computeNavBar();
    this.loadUserInfo();
  },

  onShow() {
    this.loadUserInfo();
  },

  computeNavBar() {
    try {
      const windowInfo = wx.getWindowInfo();
      const menuBtn = wx.getMenuButtonBoundingClientRect();
      this.setData({
        navBarHeight: (menuBtn.top - windowInfo.statusBarHeight) * 2 + menuBtn.height + windowInfo.statusBarHeight,
        statusBarHeight: windowInfo.statusBarHeight,
      });
    } catch (e) {}
  },

  goBack() {
    wx.navigateBack();
  },

  loadUserInfo() {
    const userInfo = wx.getStorageSync('userInfo') || {};
    let vipLevelText = '普通用户';
    if (userInfo.vipLevel === 'month') vipLevelText = '月度会员';
    if (userInfo.vipLevel === 'year') vipLevelText = '年度会员';

    let vipExpireTime = '';
    if (userInfo.vipExpireTime) {
      const date = new Date(userInfo.vipExpireTime);
      vipExpireTime = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    }

    this.setData({
      userInfo,
      vipLevel: userInfo.vipLevel || 'free',
      vipLevelText,
      vipExpireTime,
    });
  },

  selectPlan(e) {
    wx.vibrateShort({ type: 'light' });
    this.setData({ selectedPlan: e.currentTarget.dataset.plan });
  },

  async subscribe() {
    const { selectedPlan } = this.data;
    
    // 检查是否已登录
    const userInfo = wx.getStorageSync('userInfo');
    if (!userInfo || !userInfo.nickName) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }

    wx.showToast({ title: '支付功能开发中', icon: 'none' });
  },

  onShareAppMessage() {
    return {
      title: '照片工坊 - 开通会员',
      path: '/pages/member/member',
    };
  },
});
