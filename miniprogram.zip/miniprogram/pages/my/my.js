// pages/my/my.js - 我的页面
Page({
  data: {
    userInfo: null,
    isVip: false,
    stats: { createCount: 0, favorites: 0, shares: 0 },
    menuItems: [
      { id: 'history', name: '我的作品' },
      { id: 'favorites', name: '我的收藏' },
      { id: 'vip', name: '开通会员' },
      { id: 'settings', name: '设置' },
      { id: 'help', name: '帮助与反馈' },
    ],
    navBarHeight: 44,
    statusBarHeight: 20,
    tempAvatar: '',
    tempNickName: '',
    showLoginPopup: false, // 登录弹窗
  },

  onLoad() {
    this.computeNavBar();
    this.silentLogin();
  },

  onShow() {
    this.syncUserInfo();

    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: 3 });
    }
  },

  computeNavBar() {
    try {
      const windowInfo = wx.getWindowInfo();
      const menuBtn = wx.getMenuButtonBoundingClientRect();
      this.setData({
        navBarHeight: (menuBtn.top - windowInfo.statusBarHeight) * 2 + menuBtn.height + windowInfo.statusBarHeight,
        statusBarHeight: windowInfo.statusBarHeight,
      });
    } catch (e) {}
  },

  // 静默登录
  silentLogin() {
    wx.login({
      success: res => {
        if (res.code) {
          wx.setStorageSync('loginCode', res.code);
        }
      }
    });
  },

  // 点击一键登录按钮 - 打开登录弹窗
  onLoginTap() {
    this.setData({
      showLoginPopup: true,
      tempAvatar: '',
      tempNickName: '',
    });
  },

  // 关闭登录弹窗
  closeLoginPopup() {
    this.setData({ showLoginPopup: false });
  },

  // 阻止事件穿透
  preventTap() {},

  // 选择头像
  onChooseAvatar(e) {
    const avatarUrl = e.detail.avatarUrl;
    if (avatarUrl) {
      this.setData({ tempAvatar: avatarUrl });
      this.checkAndLogin();
    }
  },

  // 昵称输入
  onNickNameInput(e) {
    this.setData({ tempNickName: e.detail.value });
  },

  // 昵称确认
  onNickNameConfirm(e) {
    const nickName = e.detail.value;
    this.setData({ tempNickName: nickName });
    this.checkAndLogin();
  },

  // 检查并自动登录
  checkAndLogin() {
    const { tempAvatar, tempNickName } = this.data;
    // 只有头像和昵称都有了才自动登录
    if (tempAvatar && tempNickName && tempNickName.trim().length > 0) {
      this.doLogin();
    }
  },

  // 确认登录按钮
  confirmLogin() {
    const { tempAvatar, tempNickName } = this.data;
    if (!tempAvatar) {
      wx.showToast({ title: '请先选择头像', icon: 'none' });
      return;
    }
    if (!tempNickName || tempNickName.trim().length === 0) {
      wx.showToast({ title: '请设置昵称', icon: 'none' });
      return;
    }
    this.doLogin();
  },

  // 执行登录
  doLogin() {
    const { tempAvatar, tempNickName } = this.data;

    // 构建用户信息
    const userInfo = {
      nickName: tempNickName.trim(),
      avatarUrl: tempAvatar,
      vipLevel: 'free',
      loginTime: Date.now(),
      token: 'wx_' + Date.now(),
    };

    // 保存到用户数据
    wx.setStorageSync('userInfo', userInfo);
    wx.setStorageSync('token', userInfo.token);

    // 更新全局
    const app = getApp();
    app.globalData.userInfo = userInfo;
    app.globalData.token = userInfo.token;
    app.globalData.isVip = false;

    // 关闭弹窗
    this.setData({ showLoginPopup: false });

    // 同步用户信息
    this.syncUserInfo();

    wx.showToast({ title: '登录成功', icon: 'success' });
  },

  // 同步用户信息
  syncUserInfo() {
    try {
      const userInfo = wx.getStorageSync('userInfo');
      
      if (userInfo && userInfo.nickName) {
        this.setData({
          userInfo: userInfo,
          isVip: !!(userInfo.vipLevel && userInfo.vipLevel !== 'free'),
          stats: {
            createCount: userInfo.createCount || 0,
            favorites: userInfo.favorites || 0,
            shares: userInfo.shares || 0,
          },
        });
      } else {
        this.setData({
          userInfo: null,
          isVip: false,
          stats: { createCount: 0, favorites: 0, shares: 0 },
        });
      }
    } catch (e) {}
  },

  // 菜单点击
  onMenuTap(e) {
    const id = e.currentTarget.dataset.id;
    
    if (!this.data.userInfo && ['history', 'favorites', 'vip'].includes(id)) {
      wx.showModal({
        title: '提示',
        content: '请先登录后再操作',
        confirmText: '去登录',
        success: res => {
          if (res.confirm) {
            wx.showToast({ title: '请点击上方登录按钮', icon: 'none' });
          }
        },
      });
      return;
    }
    
    wx.vibrateShort({ type: 'light' });
    
    const routes = {
      history: '/pages/history/history',
      favorites: '/pages/favorites/favorites',
      vip: '/pages/member/member',
      settings: '/pages/settings/settings',
    };
    
    if (routes[id]) {
      wx.navigateTo({ url: routes[id] });
    } else if (id === 'help') {
      wx.showModal({
        title: '帮助与反馈',
        content: '请联系客服：support@example.com',
        showCancel: false,
      });
    } else {
      wx.showToast({ title: '功能开发中', icon: 'none' });
    }
  },

  onShareAppMessage() {
    return {
      title: '照片工坊 - 让照片更有温度',
      path: '/pages/index/index',
    };
  },
});
