// pages/index/index.js - 自然文案·暖色调·真实感
const { callFunction, wxLogin, checkLogin } = require('../../utils/cloud');

// 分类入口 - 使用真实图标
const CATEGORIES = [
  { id: 'portrait', name: '写真', icon: '/images/icons/camera.png', bg: '#F5F0E8' },
  { id: 'art', name: '创意', icon: '/images/icons/brush.png', bg: '#F5EDE8' },
  { id: 'id_photo', name: '证件照', icon: '/images/icons/idcard.png', bg: '#E8F0EE' },
  { id: 'anime', name: '二次元', icon: '/images/icons/star.png', bg: '#F5F2E8' },
  { id: 'restore', name: '老照片', icon: '/images/icons/clock.png', bg: '#EDF0E8' },
  { id: 'style', name: '换风格', icon: '/images/icons/magic.png', bg: '#F5F0EB' },
];

// Banner文案 - 自然、像朋友说话
const BANNERS = [
  { 
    bg: 'warm', 
    emoji: '📸', 
    badge: '本周热门', 
    title: '给自己拍套写真', 
    desc: '不用去照相馆，在家就能拍',
    btnText: '试试看'
  },
  { 
    bg: 'cream', 
    emoji: '🎨', 
    badge: '', 
    title: '画出心里的画面', 
    desc: '想画什么，说出来就行',
    btnText: '开始画'
  },
  { 
    bg: 'sage', 
    emoji: '✨', 
    badge: '新上线', 
    title: '证件照也能很好看', 
    desc: '自动换背景，自然又精神',
    btnText: '制作'
  },
];

// 热门模板 - 使用本地图片
const HOT_TEMPLATES = [
  { 
    id: 't1', 
    name: '证件照', 
    tag: '热门', 
    tagType: 'hot',
    cover: '/images/covers/cover-portrait.jpg',
    uses: '12.8万' 
  },
  { 
    id: 't2', 
    name: '日系写真', 
    tag: '新品', 
    tagType: 'new',
    cover: '/images/covers/cover-art.jpg',
    uses: '8.6万' 
  },
  { 
    id: 't3', 
    name: '国风', 
    tag: '', 
    tagType: '',
    cover: '/images/covers/cover-chinese.jpg',
    uses: '6.3万' 
  },
  { 
    id: 't4', 
    name: '水彩风', 
    tag: '', 
    tagType: '',
    cover: '/images/covers/cover-watercolor.jpg',
    uses: '5.1万' 
  },
  { 
    id: 't5', 
    name: '老照片修复', 
    tag: '', 
    tagType: '',
    cover: '/images/covers/cover-cyberpunk.jpg',
    uses: '4.8万' 
  },
];

// 灵感画廊图片 - 使用本地图片
const INSPIRE_IMAGES = {
  warm: '/images/covers/inspire-warm.jpg',
  cream: '/images/covers/cover-anime.jpg',
  sage: '/images/covers/cover-clay.jpg',
  sunset: '/images/covers/cover-portrait.jpg',
  rose: '/images/covers/cover-chinese.jpg',
};

// 社区精选图片
const COMMUNITY_IMAGES = [
  '/images/covers/cover-portrait.jpg',
  '/images/covers/cover-art.jpg',
  '/images/covers/cover-chinese.jpg',
  '/images/covers/cover-watercolor.jpg',
  '/images/covers/cover-cyberpunk.jpg',
  '/images/covers/cover-clay.jpg',
];

Page({
  data: {
    categories: CATEGORIES,
    banners: BANNERS,
    hotTemplates: HOT_TEMPLATES,
    inspireImages: INSPIRE_IMAGES,
    communityImages: COMMUNITY_IMAGES,
    skeletonVisible: true,
    navBarHeight: 44,
    statusBarHeight: 20,
    menuBtnHeight: 32,
    menuBtnTop: 80,
  },

  onLoad() {
    this.computeNavBar();
    setTimeout(() => this.setData({ skeletonVisible: false }), 600);
  },
  
  onShow() {
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: 0 });
    }
  },

  computeNavBar() {
    try {
      const menu = wx.getMenuButtonBoundingClientRect();
      const windowInfo = wx.getWindowInfo();
      this.setData({
        navBarHeight: (menu.top - windowInfo.statusBarHeight) * 2 + menu.height,
        statusBarHeight: windowInfo.statusBarHeight,
        menuBtnHeight: menu.height,
        menuBtnTop: menu.top,
      });
    } catch (e) {
      console.log('nav bar compute error:', e);
    }
  },

  onCategoryTap(e) {
    const cat = e.currentTarget.dataset.cat;
    wx.navigateTo({ url: '/pages/create/create?type=' + cat.id });
  },
  
  onTemplateTap(e) {
    const tpl = e.currentTarget.dataset.tpl;
    wx.navigateTo({ url: '/pages/create/create?tpl=' + tpl.id });
  },
  
  onInspireTap(e) {
    const type = e.currentTarget.dataset.type;
    wx.navigateTo({ url: '/pages/create/create?style=' + type });
  },

  // 预览图片 - 跳转到详情页
  previewImage(e) {
    const src = e.currentTarget.dataset.src;
    wx.navigateTo({
      url: `/pages/preview/preview?url=${encodeURIComponent(src)}&title=灵感作品`
    });
  },

  // 点击做同款 - 跳转到创作页
  onMakeSame(e) {
    console.log('点击做同款:', e);
    const style = e.currentTarget.dataset.style;
    const cover = e.currentTarget.dataset.cover;
    console.log('style:', style, 'cover:', cover);

    if (!cover) {
      wx.showToast({ title: '图片未加载', icon: 'none' });
      return;
    }

    // 创作页是 tabBar 页面，不能用 navigateTo，需要用 switchTab
    // 通过 storage 传递参数
    wx.setStorageSync('makeSameParams', {
      style: style,
      cover: cover,
    });

    wx.switchTab({
      url: '/pages/create/create',
      fail: (err) => {
        console.error('跳转失败:', err);
        wx.showToast({ title: '跳转失败', icon: 'none' });
      }
    });
  },
  
  goDiscover() { 
    wx.switchTab({ url: '/pages/discover/discover' }); 
  },
  
  onShareAppMessage() { 
    return { 
      title: '照片工坊 - 让照片更有温度', 
      path: '/pages/index/index' 
    }; 
  },
});
