// app.js - 全局入口
const CLOUD_ENV = 'cloud1-7g56gaj702c99bfd';

App({
  onLaunch() {
    if (!wx.cloud) {
      console.error('基础库版本过低');
      return;
    }

    // 获取系统信息
    const windowInfo = wx.getWindowInfo();
    this.globalData.windowInfo = windowInfo;

    // 胶囊按钮位置
    try {
      const menuBtn = wx.getMenuButtonBoundingClientRect();
      this.globalData.menuBtn = menuBtn;
      this.globalData.statusBarHeight = windowInfo.statusBarHeight;
      this.globalData.navBarHeight = (menuBtn.top - windowInfo.statusBarHeight) * 2 + menuBtn.height + windowInfo.statusBarHeight;
    } catch (e) {
      console.error('获取胶囊按钮失败:', e);
    }

    // 安全区域
    this.globalData.safeArea = windowInfo.safeArea;
    this.globalData.safeBottom = windowInfo.screenHeight - windowInfo.safeArea.bottom;

    // 初始化云开发
    wx.cloud.init({ env: CLOUD_ENV, traceUser: true });

    // 检查隐私协议
    this.checkPrivacyAgreement();

    // 恢复登录状态
    this.restoreLoginState();
  },

  // 检查隐私协议
  checkPrivacyAgreement() {
    try {
      const agreed = wx.getStorageSync('privacyAgreed');
      if (!agreed) {
        // 标记需要显示隐私协议
        this.globalData.needShowPrivacy = true;
      }
    } catch (e) {}
  },

  // 标记隐私协议已同意
  agreePrivacy() {
    wx.setStorageSync('privacyAgreed', true);
    this.globalData.needShowPrivacy = false;
  },

  // 恢复登录状态
  restoreLoginState() {
    try {
      const token = wx.getStorageSync('token');
      const userInfo = wx.getStorageSync('userInfo');
      
      if (token && userInfo && userInfo.nickName) {
        this.globalData.token = token;
        this.globalData.userInfo = userInfo;
        this.globalData.isVip = userInfo.vipLevel && userInfo.vipLevel !== 'free';
        console.log('✅ 自动恢复登录:', userInfo.nickName);
      } else {
        console.log('📱 未登录状态');
      }
    } catch (e) {
      console.error('恢复登录状态失败:', e);
    }
  },

  globalData: {
    token: null,
    userInfo: null,
    isVip: false,
    windowInfo: null,
    menuBtn: null,
    statusBarHeight: 0,
    navBarHeight: 0,
    safeArea: null,
    safeBottom: 0,
    needShowPrivacy: false,
  },
});
